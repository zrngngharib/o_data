<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Zain:wght@200;300;400;700;800;900&display=swap" rel="stylesheet">

<!-- Tailwind CSS -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.2.4/dist/tailwind.min.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- RTL Support -->
<style>
    body {
        direction: rtl;
        font-family: 'Zain', sans-serif;
    }
</style>
<?php
// ڕێچکەی پەڕگە: /c:/xampp/htdocs/o_data/index.php

// تێکەڵکردنی پەیوەندیدانی بنکەی داتا
include 'includes/db.php'; // ڕێڕەوی دروست بۆ `db.php`

// دەستپێکردنی ئینتەرنێت
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// پشکنینی ئەگەر بەکارهێنەر چوونەژورەوە
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}

echo "<h1>بەخێربێن بۆ O_DATA</h1>";
echo "<a href='views/tasks.php'>ئەركەكانی ڕۆژانە</a><br>";
echo "<a href='views/devices.php'>ئامێرەكان</a><br>";
echo "<a href='views/users.php'>بەكارهێنەران</a><br>";
echo "<a href='views/telegram_bot.php'>بۆتی تیلیگرام</a><br>";
echo "<a href='views/daily_check.php'>پشکنینی ڕۆژانە</a><br>";
?>

<!-- Adding logout button -->
<form action="logout.php" method="post">
    <button type="submit">دەرچوون</button>
</form>

<!-- Bootstrap Bundle JS (including Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
