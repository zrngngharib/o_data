<?php
session_start();
include '../../includes/db.php'; // ڕێڕەوی دروست بۆ `db.php`

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['selected_tasks'])) {
    $selected_tasks = $_POST['selected_tasks'];
    $action = $_POST['action'];

    if ($action == 'delete') {
        $ids = implode(',', $selected_tasks);
        $query = "DELETE FROM tasks WHERE id IN ($ids)";
        mysqli_query($conn, $query);
    } elseif ($action == 'complete') {
        $ids = implode(',', $selected_tasks);
        $query = "UPDATE tasks SET status='Completed' WHERE id IN ($ids)";
        mysqli_query($conn, $query);
    }
}


header('Location: ../tasks.php');
exit();
?>