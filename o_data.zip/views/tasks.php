<?php
session_start();
include '../includes/db.php'; // ڕێڕەوی دروست بۆ `db.php`

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$order_by = 'date DESC'; // ڕیزبەندی بنەڕەتی بەپێی نوێترین

if (isset($_GET['sort'])) {
    switch ($_GET['sort']) {
        case 'newest':
            $order_by = 'date DESC';
            break;
        case 'oldest':
            $order_by = 'date ASC';
            break;
        case 'pending':
            $order_by = "status = 'Pending' DESC, date DESC";
            break;
        case 'in_progress':
            $order_by = "status = 'In Progress' DESC, date DESC";
            break;
    }
}

// پەیجینەیشن
$tasks_per_page = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $tasks_per_page;

$query_total = "SELECT COUNT(*) as total FROM tasks WHERE status != 'Completed'";
$result_total = mysqli_query($conn, $query_total);
$row_total = mysqli_fetch_assoc($result_total);
$total_tasks = $row_total['total'];
$total_pages = ceil($total_tasks / $tasks_per_page);

$query = "SELECT * FROM tasks WHERE status != 'Completed' ORDER BY $order_by LIMIT $tasks_per_page OFFSET $offset";
$result = mysqli_query($conn, $query);

// ژمارەی کارەکان بەپێی حاڵەت
$query_pending = "SELECT COUNT(*) as total FROM tasks WHERE status = 'Pending'";
$result_pending = mysqli_query($conn, $query_pending);
$row_pending = mysqli_fetch_assoc($result_pending);
$total_pending = $row_pending['total'];

$query_in_progress = "SELECT COUNT(*) as total FROM tasks WHERE status = 'In Progress'";
$result_in_progress = mysqli_query($conn, $query_in_progress);
$row_in_progress = mysqli_fetch_assoc($result_in_progress);
$total_in_progress = $row_in_progress['total'];

$query_completed = "SELECT COUNT(*) as total FROM tasks WHERE status = 'Completed'";
$result_completed = mysqli_query($conn, $query_completed);
$row_completed = mysqli_fetch_assoc($result_completed);
$total_completed = $row_completed['total'];
?>
<!DOCTYPE html>
<html lang="ku">
<head>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Zain:wght@200;300;400;700;800;900&display=swap" rel="stylesheet">

<!-- Tailwind CSS -->
<link href="https://cdn.jsdelivr.net/npm/tailwindcss@3.2.4/dist/tailwind.min.css" rel="stylesheet">

<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- RTL Support -->
<style>
    body {
        direction: rtl;
        font-family: 'Zain', sans-serif;
    }
</style>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ئەركەكانی ڕۆژانە</title>
    <link rel="stylesheet" href="../styles.css">
    <script>
        function updateSort() {
            const sort = document.getElementById('sort').value;
            window.location.href = `tasks.php?sort=${sort}`;
        }

        function confirmAction(action) {
            const message = action === 'delete' ? 'دڵنیای لە ئەنجامدانی ئەم کارە؟' : 'دڵنیای لە ئەنجامدانی ئەم کارە؟';
            return confirm(message);
        }

        function searchTasks() {
            const input = document.getElementById('search').value.toLowerCase();
            const table = document.querySelector('table');
            const rows = table.getElementsByTagName('tr');

            for (let i = 1; i < rows.length; i++) {
                const cells = rows[i].getElementsByTagName('td');
                let match = false;

                for (let j = 1; j < cells.length; j++) {
                    if (cells[j].innerText.toLowerCase().includes(input)) {
                        match = true;
                        break;
                    }
                }

                rows[i].style.display = match ? '' : 'none';
            }
        }
    </script>
</head>
<body>
    <h1>ئەركەكانی ڕۆژانە</h1>
    <button onclick="window.location.href='tasks/add_task.php'">➕ زیاد كردن</button>
    <button onclick="window.location.href='tasks/pending_tasks.php'">⏳ کارە چاوەڕوانەکان</button>
    <button onclick="window.location.href='tasks/completed_tasks.php'">✅ کارە تەواوبووەکان</button>
    <button onclick="window.location.href='tasks/report.php'">📊 ڕاپۆرتی گشتی</button>
    <input type="text" id="search" placeholder="🔍 گەڕان بپێی ئەرك، ژمارە، شوێن، كارمەند..." onkeyup="searchTasks()">
    <br><br>
    <label>ڕیزبەندی:</label>
    <select id="sort" onchange="updateSort()">
        <option value="newest" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'newest') echo 'selected'; ?>>نوێترین</option>
        <option value="oldest" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'oldest') echo 'selected'; ?>>کۆنترین</option>
        <option value="pending" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'pending') echo 'selected'; ?>>Pending</option>
        <option value="in_progress" <?php if (isset($_GET['sort']) && $_GET['sort'] == 'in_progress') echo 'selected'; ?>>In Progress</option>
    </select>
    <span> | </span>
    <div style="display: inline;">
    <span>بڕۆ بۆ لاپەڕەی: </span>
        <?php
        for ($i = 1; $i <= $total_pages; $i++) {
            echo "<a href='tasks.php?page=$i&sort=" . (isset($_GET['sort']) ? $_GET['sort'] : 'newest') . "'>$i</a> ";
        }
        ?>
    </div>
    <br><br>
    <div>
        <p>چاوەڕوانی: <?php echo $total_pending; ?></p>
        <p>کارکردن بەردەوامە: <?php echo $total_in_progress; ?></p>
        <p>تەواوبووەکان: <?php echo $total_completed; ?></p>
    </div>
    <form method="POST" action="tasks/bulk_action.php" onsubmit="return confirmAction(this.action.value)">
        <table border="1">
            <tr>
            <th>🎯 </th>
                <th>ID </th>
                <th>ئەرك 📋</th>
                <th>ژمارە 🔢</th>
                <th>شوێن 📍</th>
                <th>کارمەند 👤</th>
                <th>ژمارە مۆبایل 📞</th>
                <th>تیم 👥</th>
                <th>حاڵەت 📊</th>
                <th>نرخ 💰</th>
                <th>بەروار 📅</th>
                <th>کردار ⚙️</th>
            </tr>
            <?php
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td><input type='checkbox' name='selected_tasks[]' value='{$row['id']}'></td>";
                echo "<td>{$row['id']}</td>";
                echo "<td>{$row['task_name']}</td>";
                echo "<td>{$row['task_number']}</td>";
                echo "<td>{$row['location']}</td>";
                echo "<td>{$row['employee']}</td>";
                echo "<td>{$row['mobile_number']}</td>";
                echo "<td>{$row['team']}</td>";
                echo "<td>{$row['status']}</td>";
                echo "<td>{$row['cost']} {$row['currency']}</td>";
                echo "<td>{$row['date']}</td>";
                echo "<td>
                        <a href='tasks/edit_task.php?id={$row['id']}'>✏️ دەستکاری</a> |
                        <a href='tasks/copy_task.php?id={$row['id']}'>📋 کۆپی</a> |
                        <a href='tasks/delete_task.php?id={$row['id']}'>❌ سڕینەوە</a>                   
                      </td>";
                echo "</tr>";
            }
            ?>
        </table>
        <br>
        <button type="submit" name="action" value="delete">❌ سڕینەوەی بەکۆمەڵ</button>
        <button type="submit" name="action" value="complete">✅ تەواوکردنی بەکۆمەڵ</button>
    </form>
    <br>

<!-- Bootstrap Bundle JS (including Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>