// filepath: /c:/xampp/htdocs/o_data/js/scripts.js
import '../includes/db.php';
import '../includes/functions.php';
import '../includes/header.php';
import '../includes/footer.php';
import '../includes/sidebar.php';
import '../includes/navbar.php';
import '../includes/aside.php';
import '../includes/main.php';
import '../includes/section.php';
import '../includes/article.php';
import '../includes/div.php';
import '../includes/span.php';
import '../includes/form.php';
import '../includes/input.php';
import '../includes/button.php';
import '../includes/textarea.php';
import '../includes/select.php';
import '../includes/option.php';
import '../includes/label.php';
import '../includes/fieldset.php';
import '../includes/legend.php';
import '../includes/table.php';
import '../includes/tr.php';
import '../includes/th.php';
import '../includes/td.php';
import '../includes/tfoot.php';
import '../includes/thead.php';
import '../includes/tbody.php';
import '../includes/ul.php';
import '../includes/ol.php';
import '../includes/li.php';
import '../includes/a.php';
import '../includes/h1.php';
import '../includes/h2.php';
import '../includes/h3.php';


// Add JavaScript code here
س